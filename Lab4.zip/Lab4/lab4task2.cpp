#include <iostream>
using namespace std;

int main()
{
    const int size = 9;
    int arr[size] = {2, 12, 15, 2, 10, 1, 13, 9, 5};

    for (int i = 1; i < size; i++)
    {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }

    int sorted[size];
    int maxElement = arr[size - 1];
    int mid = size / 2;

    for (int i = 0; i < mid; i++)
    {
        sorted[i] = arr[i];
    }
    sorted[mid] = maxElement;
    for (int i = mid + 1, j = mid; i < size; i++, j++)
    {
        sorted[i] = arr[j];
    }

    cout << "Sorted array: ";
    for (int i = 0; i < size; i++)
    {
        cout << sorted[i] << " ";
    }

    return 0;
}
