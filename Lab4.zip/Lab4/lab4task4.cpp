#include <iostream>
using namespace std;

bool hasDuplicates(int arr[], int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (arr[i] == arr[j])
            {
                return true;
            }
        }
    }
    return false;
}

int main()
{
    int arr[] = {4, 2, 7, 1, 9, 2, 5};
    int size = sizeof(arr) / sizeof(arr[0]);

    if (hasDuplicates(arr, size))
    {
        cout << "array contains duplicates";
    }
    else
    {
        cout << "array has unique elements";
    }

    return 0;
}
