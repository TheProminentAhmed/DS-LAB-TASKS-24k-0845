#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *nextpointer;

    Node(int v) : val(v)
    {
        nextpointer = NULL;
    }
};
class LinkedList
{
public:
    Node *Headpointer;
    Node *Tailpointer;
    LinkedList()
    {
        Headpointer = NULL;
        Tailpointer = NULL;
    }

    void insertattail(int v)
    {
        Node *newNode = new Node{v};
        if (Headpointer == NULL)
        {

            Headpointer = newNode;
            Tailpointer = newNode;
        }
        else
        {
            Node *temp = Headpointer;
            while (temp->nextpointer != NULL)
            {
                temp = temp->nextpointer;
            }
            temp->nextpointer = newNode;
            Tailpointer = newNode;
            cout << endl
                 << "insertion complete\n";
        }
    }
    void printlinkedlist()
    {
        if (Headpointer == NULL)
        {
            cout << "List is empty\n";
            return;
        }
        Node *traverse = Headpointer;
        while (traverse != NULL)
        {
            cout << traverse->val;
            if (traverse->nextpointer != NULL)
                cout << "->";
            traverse = traverse->nextpointer;
        }
        cout << "->NULL" << endl;
    }
};
void EvenOddlist(LinkedList *list)
{
    if (list->Headpointer == NULL || list->Headpointer->nextpointer == NULL)
    {
        cout << "List is empty" << endl;
        return;
    }

    LinkedList *evenList = new LinkedList();
    LinkedList *oddList = new LinkedList();
    Node *current = list->Headpointer;
    while (current->nextpointer != NULL)
    {
        if (current->val % 2 == 0)
        {
            evenList->insertattail(current->val);
        }
        else
        {
            oddList->insertattail(current->val);
        }
        current = current->nextpointer;
    }
    if (current->val % 2 == 0)
    {
        evenList->insertattail(current->val);
    }
    else
    {
        oddList->insertattail(current->val);
    }
    evenList->Tailpointer->nextpointer = oddList->Headpointer;
    list->Headpointer = evenList->Headpointer;
    list->Tailpointer = oddList->Tailpointer;
    delete evenList;
    delete oddList;
}
int main()
{
    LinkedList *list = new LinkedList();
    list->insertattail(5);
    list->insertattail(6);
    list->insertattail(3);
    list->insertattail(2);
    list->insertattail(1);
    list->insertattail(8);
    list->insertattail(4);
    list->printlinkedlist();
    EvenOddlist(list);
    list->printlinkedlist();
}
