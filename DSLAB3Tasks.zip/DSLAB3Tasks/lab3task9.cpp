#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *next;

    Node(int v) : val(v), next(NULL) {}
};

class LinkedList
{
public:
    Node *head;
    Node *tail;

    LinkedList()
    {
        head = NULL;
        tail = NULL;
    }

    void insertAtTail(int v)
    {
        Node *newNode = new Node(v);
        if (!head)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
    }

    void printList()
    {
        Node *temp = head;
        while (temp)
        {
            cout << temp->val << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

Node *reverseList(Node *head)
{
    Node *prev = NULL;
    Node *curr = head;
    Node *next = NULL;

    while (curr)
    {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}

void rearrange(LinkedList &list)
{
    if (!list.head || !list.head->next)
        return;

    Node *odd = list.head;
    Node *even = list.head->next;
    Node *evenHead = even;

    while (odd->next && even->next)
    {
        odd->next = even->next;
        odd = odd->next;
        if (odd->next)
        {
            even->next = odd->next;
            even = even->next;
        }
        else
        {
            even->next = NULL;
            break;
        }
    }

    Node *reversedEven = reverseList(evenHead);
    odd->next = reversedEven;
}

int main()
{
    LinkedList list;
    int arr[8] = {10, 4, 9, 1, 3, 5, 9, 4};

    for (int i = 0; i < 8; i++)
    {
        list.insertAtTail(arr[i]);
    }

    cout << "Original list: ";
    list.printList();

    rearrange(list);

    cout << "Modified list: ";
    list.printList();

    return 0;
}
