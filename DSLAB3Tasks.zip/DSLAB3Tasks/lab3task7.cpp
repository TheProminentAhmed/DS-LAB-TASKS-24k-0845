#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *nextpointer;

    Node(int v) : val(v), nextpointer(NULL) {}
};

class CircularLinkedList
{
public:
    Node *Headpointer;
    Node *Tailpointer;

    CircularLinkedList()
    {
        Headpointer = NULL;
        Tailpointer = NULL;
    }

    void insertathead(int v)
    {
        Node *newNode = new Node(v);
        if (Headpointer == NULL)
        {
            Headpointer = Tailpointer = newNode;
            Tailpointer->nextpointer = Headpointer;
        }
        else
        {
            newNode->nextpointer = Headpointer;
            Headpointer = newNode;
            Tailpointer->nextpointer = Headpointer;
        }
    }

    void insertattail(int v)
    {
        Node *newNode = new Node(v);
        if (Headpointer == NULL)
        {
            Headpointer = Tailpointer = newNode;
            Tailpointer->nextpointer = Headpointer;
        }
        else
        {
            Tailpointer->nextpointer = newNode;
            Tailpointer = newNode;
            Tailpointer->nextpointer = Headpointer;
        }
    }

    void insertinbetween(int v, int pos)
    {
        if (Headpointer == NULL || pos == 1)
        {
            insertathead(v);
            return;
        }
        Node *locater = Headpointer;
        for (int i = 1; i < pos - 1 && locater->nextpointer != Headpointer; i++)
        {
            locater = locater->nextpointer;
        }
        Node *newNode = new Node(v);
        newNode->nextpointer = locater->nextpointer;
        locater->nextpointer = newNode;

        if (locater == Tailpointer)
        {
            Tailpointer = newNode;
        }
    }

    void deleteNode(int v)
    {
        if (Headpointer == NULL)
        {
            cout << "List empty\n";
            return;
        }

        Node *traverse = Headpointer;
        Node *prev = Tailpointer;

        do
        {
            if (traverse->val == v)
            {
                if (traverse == Headpointer)
                {
                    Headpointer = Headpointer->nextpointer;
                    Tailpointer->nextpointer = Headpointer;
                    delete traverse;
                }
                else
                {
                    prev->nextpointer = traverse->nextpointer;
                    if (traverse == Tailpointer)
                    {
                        Tailpointer = prev;
                    }
                    delete traverse;
                }
                return;
            }
            prev = traverse;
            traverse = traverse->nextpointer;
        } while (traverse != Headpointer);

        cout << "Value not found\n";
    }

    void printlinkedlist()
    {
        if (Headpointer == NULL)
        {
            cout << "List is empty\n";
            return;
        }
        Node *traverse = Headpointer;
        do
        {
            cout << traverse->val << "->";
            traverse = traverse->nextpointer;
        } while (traverse != Headpointer);
        cout << "(back to Head)" << endl;
    }
};

int main()
{
    int arr[5] = {3, 1, 2, 5, 8};
    CircularLinkedList Array;

    cout << "Original Array: ";
    for (int i = 0; i < 5; i++)
    {
        cout << arr[i] << "-->";
    }
    cout << "NULL\n";

    for (int i = 0; i < 5; i++)
    {
        Array.insertattail(arr[i]);
    }
    Array.printlinkedlist();

    Array.insertattail(9);
    Array.printlinkedlist();

    Array.insertathead(4);
    Array.printlinkedlist();

    Array.insertinbetween(11, 3);
    Array.printlinkedlist();

    Array.deleteNode(1);
    Array.printlinkedlist();

    Array.deleteNode(9);
    Array.printlinkedlist();

    return 0;
}
