#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *nextpointer;

    Node(int v) : val(v)
    {
        nextpointer = NULL;
    }
};
class LinkedList
{
public:
    Node *Headpointer;
    Node *Tailpointer;
    LinkedList()
    {
        Headpointer = NULL;
        Tailpointer = NULL;
    }

    void insertattail(int v)
    {
        Node *newNode = new Node{v};
        if (Headpointer == NULL)
        {

            Headpointer = newNode;
            Tailpointer = newNode;
        }
        else
        {
            Node *temp = Headpointer;
            while (temp->nextpointer != NULL)
            {
                temp = temp->nextpointer;
            }
            temp->nextpointer = newNode;
            Tailpointer = newNode;
            cout << endl
                 << "insertion complete\n";
        }
    }
    void printlinkedlist()
    {
        if (Headpointer == NULL)
        {
            cout << "List is empty\n";
            return;
        }
        Node *traverse = Headpointer;
        while (traverse != NULL)
        {
            cout << traverse->val;
            if (traverse->nextpointer != NULL)
                cout << "->";
            traverse = traverse->nextpointer;
        }
        cout << "->NULL" << endl;
    }
    void ShiftElements(int num)
    {
        if (Headpointer == NULL || Headpointer->nextpointer == NULL)
        {
            return;
        }
        Node *temp = Headpointer;
        for (int i = 0; i < num; i++)
        {
            temp = temp->nextpointer;
        }
        LinkedList *newList = new LinkedList();
        while (temp->nextpointer != NULL)
        {
            newList->insertattail(temp->val);
            temp = temp->nextpointer;
        }
        newList->insertattail(temp->val);
        Node *temp2 = Headpointer;
        for (int i = 0; i < num; i++)
        {
            newList->insertattail(temp2->val);
            temp2 = temp2->nextpointer;
        }
        Node *freeing = Headpointer;
        while (freeing != NULL)
        {
            Node *next = freeing->nextpointer;
            delete freeing;
            freeing = next;
        }
        Headpointer = newList->Headpointer;
        Tailpointer = newList->Tailpointer;
        delete newList;
        return;
        delete temp2;
        delete temp;
    }
};
int main()
{
    LinkedList *list = new LinkedList();
    list->insertattail(5);
    list->insertattail(3);
    list->insertattail(1);
    list->insertattail(8);
    list->insertattail(6);
    list->insertattail(4);
    list->insertattail(2);
    list->printlinkedlist();
    list->ShiftElements(2);
    list->printlinkedlist();
}