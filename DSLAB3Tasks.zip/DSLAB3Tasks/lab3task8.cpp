#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *next;
    Node *prev;

    Node(int v) : val(v), next(NULL), prev(NULL) {}
};

class DoublyLinkedList
{
public:
    Node *Head;
    Node *Tail;

    DoublyLinkedList()
    {
        Head = NULL;
        Tail = NULL;
    }

    void insertAtTail(int v)
    {
        Node *newNode = new Node(v);
        if (Head == NULL)
        {
            Head = newNode;
            Tail = newNode;
        }
        else
        {
            Tail->next = newNode;
            newNode->prev = Tail;
            Tail = newNode;
        }
    }

    void printList()
    {
        if (Head == NULL)
        {
            cout << "List is empty\n";
            return;
        }
        Node *traverse = Head;
        while (traverse != NULL)
        {
            cout << traverse->val;
            if (traverse->next != NULL)
                cout << " <-> ";
            traverse = traverse->next;
        }
        cout << " -> NULL" << endl;
    }
};

void concatenate(DoublyLinkedList &L, DoublyLinkedList &M)
{
    if (L.Head == NULL)
    {
        L.Head = M.Head;
        L.Tail = M.Tail;
    }
    else if (M.Head != NULL)
    {
        L.Tail->next = M.Head;
        M.Head->prev = L.Tail;
        L.Tail = M.Tail;
    }
    M.Head = NULL;
    M.Tail = NULL;
}

int main()
{
    DoublyLinkedList L, M;

    L.insertAtTail(1);
    L.insertAtTail(2);
    L.insertAtTail(3);

    M.insertAtTail(4);
    M.insertAtTail(5);
    M.insertAtTail(6);

    cout << "List l: ";
    L.printList();
    cout << "List m: ";
    M.printList();

    concatenate(L, M);

    cout << "\nAfter concatenation:\n";
    cout << "List l: ";
    L.printList();
    cout << "List m: ";
    M.printList();

    return 0;
}
