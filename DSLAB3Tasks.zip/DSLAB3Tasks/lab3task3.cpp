#include <iostream>
#include <string>
using namespace std;

class PassengerNode
{
public:
    string name;
    PassengerNode *next;
    PassengerNode(string n) : name(n), next(NULL) {}
};

class PassengerList
{
public:
    PassengerNode *head;
    PassengerList() { head = NULL; }

    void insertPassenger(string name)
    {
        PassengerNode *newNode = new PassengerNode(name);
        if (head == NULL || name < head->name)
        {
            newNode->next = head;
            head = newNode;
            return;
        }
        PassengerNode *curr = head;
        while (curr->next != NULL && curr->next->name < name)
            curr = curr->next;
        newNode->next = curr->next;
        curr->next = newNode;
    }

    void deletePassenger(string name)
    {
        if (head == NULL)
        {
            cout << "No passengers.\n";
            return;
        }
        PassengerNode *curr = head;
        PassengerNode *prev = NULL;
        while (curr != NULL)
        {
            if (curr->name == name)
            {
                if (prev == NULL)
                    head = curr->next;
                else
                    prev->next = curr->next;
                delete curr;
                cout << "Reservation cancelled.\n";
                return;
            }
            prev = curr;
            curr = curr->next;
        }
        cout << "Passenger not found.\n";
    }

    bool searchPassenger(string name)
    {
        PassengerNode *curr = head;
        while (curr != NULL)
        {
            if (curr->name == name)
                return true;
            curr = curr->next;
        }
        return false;
    }

    void printPassengers()
    {
        if (head == NULL)
        {
            cout << "No passengers.\n";
            return;
        }
        PassengerNode *curr = head;
        while (curr != NULL)
        {
            cout << curr->name;
            if (curr->next)
                cout << " -> ";
            curr = curr->next;
        }
        cout << " -> NULL\n";
    }
};

class FlightNode
{
public:
    string flightName;
    PassengerList passengers;
    FlightNode *next;
    FlightNode(string fn) : flightName(fn), next(NULL) {}
};

class FlightList
{
public:
    FlightNode *head;
    FlightList() { head = NULL; }

    FlightNode *findFlight(string flightName)
    {
        FlightNode *curr = head;
        while (curr != NULL)
        {
            if (curr->flightName == flightName)
                return curr;
            curr = curr->next;
        }
        return NULL;
    }

    void addFlight(string flightName)
    {
        if (findFlight(flightName))
        {
            cout << "Flight already exists.\n";
            return;
        }
        FlightNode *newFlight = new FlightNode(flightName);
        newFlight->next = head;
        head = newFlight;
        cout << "Flight added: " << flightName << endl;
    }

    void reserveTicket(string flightName, string passengerName)
    {
        FlightNode *flight = findFlight(flightName);
        if (!flight)
        {
            cout << "Flight not found.\n";
            return;
        }
        flight->passengers.insertPassenger(passengerName);
        cout << "Ticket reserved for " << passengerName << " in " << flightName << endl;
    }

    void cancelReservation(string flightName, string passengerName)
    {
        FlightNode *flight = findFlight(flightName);
        if (!flight)
        {
            cout << "Flight not found.\n";
            return;
        }
        flight->passengers.deletePassenger(passengerName);
    }

    void checkReservation(string flightName, string passengerName)
    {
        FlightNode *flight = findFlight(flightName);
        if (!flight)
        {
            cout << "Flight not found.\n";
            return;
        }
        if (flight->passengers.searchPassenger(passengerName))
            cout << passengerName << " has a reservation in " << flightName << endl;
        else
            cout << passengerName << " has no reservation in " << flightName << endl;
    }

    void displayPassengers(string flightName)
    {
        FlightNode *flight = findFlight(flightName);
        if (!flight)
        {
            cout << "Flight not found.\n";
            return;
        }
        cout << "Passengers in " << flightName << ":\n";
        flight->passengers.printPassengers();
    }

    void displayAllFlights()
    {
        if (head == NULL)
        {
            cout << "No flights available.\n";
            return;
        }
        FlightNode *curr = head;
        while (curr != NULL)
        {
            cout << "Flight: " << curr->flightName << "\nPassengers: ";
            curr->passengers.printPassengers();
            cout << endl;
            curr = curr->next;
        }
    }
};

int main()
{
    FlightList flights;
    int choice;
    string flightName, passengerName;

    while (true)
    {
        cout << "\n--- Airline Reservation Menu ---\n";
        cout << "1. Add Flight\n";
        cout << "2. Reserve Ticket\n";
        cout << "3. Cancel Reservation\n";
        cout << "4. Check Reservation\n";
        cout << "5. Display Passengers of a Flight\n";
        cout << "6. Display All Flights\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice)
        {
        case 1:
            cout << "Enter flight name: ";
            getline(cin, flightName);
            flights.addFlight(flightName);
            break;
        case 2:
            cout << "Enter flight name: ";
            getline(cin, flightName);
            cout << "Enter passenger name: ";
            getline(cin, passengerName);
            flights.reserveTicket(flightName, passengerName);
            break;
        case 3:
            cout << "Enter flight name: ";
            getline(cin, flightName);
            cout << "Enter passenger name: ";
            getline(cin, passengerName);
            flights.cancelReservation(flightName, passengerName);
            break;
        case 4:
            cout << "Enter flight name: ";
            getline(cin, flightName);
            cout << "Enter passenger name: ";
            getline(cin, passengerName);
            flights.checkReservation(flightName, passengerName);
            break;
        case 5:
            cout << "Enter flight name: ";
            getline(cin, flightName);
            flights.displayPassengers(flightName);
            break;
        case 6:
            flights.displayAllFlights();
            break;
        case 7:
            cout << "Exiting...\n";
            return 0;
        default:
            cout << "Invalid choice.\n";
        }
    }
}
