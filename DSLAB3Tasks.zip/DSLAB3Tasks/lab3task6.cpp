#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *nextpointer;

    Node(int v) : val(v)
    {
        nextpointer = NULL;
    }
};
class LinkedList
{
public:
    Node *Headpointer;
    Node *Tailpointer;
    LinkedList()
    {
        Headpointer = NULL;
        Tailpointer = NULL;
    }

    void insertattail(int v)
    {
        Node *newNode = new Node{v};
        if (Headpointer == NULL)
        {

            Headpointer = newNode;
        }
        else
        {
            Node *temp = Headpointer;
            while (temp->nextpointer != NULL)
            {
                temp = temp->nextpointer;
            }
            temp->nextpointer = newNode;
            cout << endl
                 << "insertion complete\n";
        }
    }
    void printlinkedlist()
    {
        if (Headpointer == NULL)
        {
            cout << "List is empty\n";
            return;
        }
        Node *traverse = Headpointer;
        while (traverse != NULL)
        {
            cout << traverse->val;
            if (traverse->nextpointer != NULL)
                cout << "->";
            traverse = traverse->nextpointer;
        }
        cout << "->NULL" << endl;
    }

    void deleteNode(int v)
    {
        if (Headpointer == NULL)
        {
            cout << "List empty\n";
            return;
        }

        Node *traverse = Headpointer;
        Node *prev = NULL;

        while (traverse != NULL)
        {
            if (traverse->val == v)
            {
                if (prev == NULL)
                {
                    Headpointer = traverse->nextpointer;
                    delete traverse;
                    cout << "Deletion complete\n";
                    return;
                }
                else
                {
                    prev->nextpointer = traverse->nextpointer;
                    delete traverse;
                    cout << "Deletion complete\n";
                    return;
                }
            }
            prev = traverse;
            traverse = traverse->nextpointer;
        }
        cout << "Value not found\n";
    }
};
int main()
{
    LinkedList Array;

    Array.insertattail(1);
    Array.insertattail(2);
    Array.insertattail(3);
    Array.insertattail(1);

    Array.printlinkedlist();

    Array.deleteNode(6);
    Array.deleteNode(2);
    Array.printlinkedlist();
}