#include <iostream>
using namespace std;

class Node
{
public:
    char val;
    Node *next;
    Node *prev;

    Node(char v) : val(v), next(NULL), prev(NULL) {}
};

class DoublyLinkedList
{
public:
    Node *head;
    Node *tail;

    DoublyLinkedList() : head(NULL), tail(NULL) {}

    void insertAtEnd(char v)
    {
        Node *newNode = new Node(v);
        if (head == NULL)
        {
            head = tail = newNode;
        }
        else
        {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    void printList()
    {
        Node *temp = head;
        while (temp)
        {
            cout << temp->val;
            if (temp->next)
                cout << "-> ";
            temp = temp->next;
        }
        cout << endl;
    }

    bool isPalindrome()
    {
        if (!head)
            return true;

        Node *left = head;
        Node *right = tail;

        while (left && right && left != right && left->prev != right)
        {
            if (left->val != right->val)
                return false;
            left = left->next;
            right = right->prev;
        }

        return true;
    }
};

int main()
{
    DoublyLinkedList dl;

    dl.insertAtEnd('a');
    dl.insertAtEnd('b');
    dl.insertAtEnd('c');
    dl.insertAtEnd('b');
    dl.insertAtEnd('a');

    dl.printList();
    cout << (dl.isPalindrome() ? "Palindrome" : "Not Palindrome") << endl;

    DoublyLinkedList dl2;
    dl2.insertAtEnd('r');
    dl2.insertAtEnd('a');
    dl2.insertAtEnd('a');
    dl2.insertAtEnd('r');

    dl2.printList();
    cout << (dl2.isPalindrome() ? "Palindrome" : "Not Palindrome") << endl;

    DoublyLinkedList dl3;
    dl3.insertAtEnd('h');
    dl3.insertAtEnd('e');
    dl3.insertAtEnd('l');
    dl3.insertAtEnd('l');
    dl3.insertAtEnd('o');

    dl3.printList();
    cout << (dl3.isPalindrome() ? "Palindrome" : "Not Palindrome") << endl;

    return 0;
}
