#include <iostream>
using namespace std;

class Node
{
public:
    int val;
    Node *nextpointer;

    Node(int v) : val(v)
    {
        nextpointer = NULL;
    }
};
class LinkedList
{
public:
    Node *Headpointer;
    Node *Tailpointer;
    LinkedList()
    {
        Headpointer = NULL;
        Tailpointer = NULL;
    }
    void insertinbetween(int v, int pos)
    {
        Node *locater;
        locater = Headpointer;
        for (int i = 1; i < pos - 1; i++)
        {
            locater = locater->nextpointer;
        }
        Node *newNode = new Node{v};
        Node *pointer = locater->nextpointer;
        locater->nextpointer = newNode;
        newNode->nextpointer = pointer;
    }
    void insertathead(int v)
    {
        Node *newNode = new Node{v};
        if (Headpointer == NULL)
        {
            Headpointer = newNode;
        }
        else
        {
            newNode->nextpointer = Headpointer;
            Headpointer = newNode;
        }
    }
    void insertattail(int v)
    {
        Node *newNode = new Node{v};
        if (Headpointer == NULL)
        {

            Headpointer = newNode;
        }
        else
        {
            Node *temp = Headpointer;
            while (temp->nextpointer != NULL)
            {
                temp = temp->nextpointer;
            }
            temp->nextpointer = newNode;
            cout << endl
                 << "insertion complete\n";
        }
    }
    void printlinkedlist()
    {
        if (Headpointer == NULL)
        {
            cout << "List is empty\n";
            return;
        }
        Node *traverse = Headpointer;
        while (traverse != NULL)
        {
            cout << traverse->val;
            if (traverse->nextpointer != NULL)
                cout << "->";
            traverse = traverse->nextpointer;
        }
        cout << "->NULL" << endl;
    }

    void deleteNode(int v)
    {
        if (Headpointer == NULL)
        {
            cout << "List empty\n";
            return;
        }

        Node *traverse = Headpointer;
        Node *prev = NULL;

        while (traverse != NULL)
        {
            if (traverse->val == v)
            {
                if (prev == NULL)
                {
                    Headpointer = traverse->nextpointer;
                    delete traverse;
                    return;
                }
                else
                {
                    prev->nextpointer = traverse->nextpointer;
                    delete traverse;
                    return;
                }
            }
            prev = traverse;
            traverse = traverse->nextpointer;
        }
        cout << "Value not found\n";
    }
};
int main()
{
    int arr[5] = {3, 1, 2, 5, 8};
    LinkedList Array;

    for (int i = 0; i < 5; i++)
    {
        cout << arr[i] << "-->";
    }
    cout << "NULL";

    for (int i = 0; i < 5; i++)
    {
        Array.insertattail(arr[i]);
    }
    Array.printlinkedlist();

    Array.insertattail(9);
    Array.printlinkedlist();
    cout << endl;
    Array.insertathead(4);
    cout << endl;
    Array.printlinkedlist();
    cout << endl;
    Array.insertinbetween(11, 3);
    Array.deleteNode(1);
    Array.printlinkedlist();
}